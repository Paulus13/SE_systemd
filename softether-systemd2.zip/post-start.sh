#!/bin/sh

set -e

VPN_IFACE=tap_se0

#for i in {1..5} ; do
for i in 1 2 3 4 5 ; do
ip link list dev $VPN_IFACE 2>&1 > /dev/null && { DONE=1 ; break;}
	echo "Wait for network interface $VPN_IFACE."
	sleep 1
done

[ "$DONE" != "1" ] && exit 1

echo "Set IP address."
ip address add 10.5.5.1/24 dev $VPN_IFACE
#iptables -A se-forward -i $VPN_IFACE -j ACCEPT
#iptables -A se-forward -o $VPN_IFACE -j ACCEPT

