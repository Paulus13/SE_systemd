#!/bin/sh

VPN_IFACE=tap_se0

#ip address del 192.168.30.1/24 dev $VPN_IFACE
#iptables -D se-forward -i $VPN_IFACE -j ACCEPT
#iptables -D se-forward -o $VPN_IFACE -j ACCEPT

