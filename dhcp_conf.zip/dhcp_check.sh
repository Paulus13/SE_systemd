#!/bin/bash

logPath=~/dhcp_check/dhcp_check.log

function initialCheck() {
if [ "$EUID" -ne 0 ]
  then printToLog "Please run as root"
  exit
fi

if [ ! -f /lib/systemd/system/isc-dhcp-server.service ]; then
	printToLog "isc-dhcp-server not installed"
	exit
fi
}

function printToLog() {
if [ -z "$1" ]
	then exit
	else line_to_print=$1
fi

#if [ ! -f $logPath ]; then
#	touch $logPath
#fi

mydate=$(date '+%d.%m.%Y %H:%M:%S')
echo $mydate $line_to_print >> $logPath
}

function checkUnitConfigured() {
se_line=$(grep 'After=softether-vpnserver.service' /lib/systemd/system/isc-dhcp-server.service)
if [[ -z $se_line ]]
	then unit_configured=0
	else unit_configured=1
fi
}

function checkServiceRunning() {
dhcp_line=$(systemctl status isc-dhcp-server.service | grep 'active (running)')
if [[ -z $dhcp_line ]]
	then service_running=0
	else service_running=1
fi
}

initialCheck
checkServiceRunning

if [[ $service_running -eq 0 ]]; then
	checkUnitConfigured
	if [[ $unit_configured -eq 0 ]]; then
		printToLog "Service dhcpd is dead. Unit configured BAD, try to reconfigure and restart service."
			
		sudo systemctl unmask isc-dhcp-server.service
		sudo install -m 644 ~/dhcp_check/isc-dhcp-server.service /lib/systemd/system
		sudo systemctl daemon-reload
		sudo systemctl restart isc-dhcp-server.service			
	else
		printToLog "Service dhcpd is dead. Unit configured GOOD, try to restart service."
		sudo systemctl restart isc-dhcp-server.service
	fi
else
	printToLog "Service dhcpd is running, no action required"
	exit
fi

checkServiceRunning
	
if [[ $service_running -eq 0 ]]; then
	if [[ $unit_configured -eq 0 ]]; then
		printToLog "Service dhcpd reconfigured and restarted, but unsuccessfully"
	else
		printToLog "Service dhcpd restarted, but unsuccessfully"
	fi
else 
	if [[ $unit_configured -eq 0 ]]; then
		printToLog "Service dhcpd reconfigured and restarted successfully"
	else
		printToLog "Service dhcpd restarted successfully"
	fi
fi
